-- JualinPro AI database starter
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  plan text not null default 'free' check (plan in ('free','pro')),
  monthly_generations int not null default 0,
  generation_reset_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create table if not exists public.ai_generations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  mode text not null,
  input_text text not null,
  output_text text not null,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.ai_generations enable row level security;
create policy "profile owner read" on public.profiles for select using (auth.uid() = id);
create policy "profile owner update" on public.profiles for update using (auth.uid() = id);
create policy "generation owner read" on public.ai_generations for select using (auth.uid() = user_id);
create policy "generation owner insert" on public.ai_generations for insert with check (auth.uid() = user_id);
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id) values (new.id) on conflict do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
