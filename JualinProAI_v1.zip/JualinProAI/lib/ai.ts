import { supabase } from './supabase';
export type AiMode='description'|'caption'|'script'|'reply';
export async function generateAI(mode:AiMode, input:string){
  const {data,error}=await supabase.functions.invoke('generate-ai',{body:{mode,input}});
  if(error) throw error;
  return data?.text ?? '';
}
