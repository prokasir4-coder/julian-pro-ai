# JualinPro AI

Aplikasi AI untuk seller/UMKM Indonesia. Starter komersial berbasis Expo + Supabase.

## Fitur yang sudah disiapkan
- Login & daftar akun Supabase
- Dashboard profesional
- AI Tools: deskripsi produk, caption, script video, balas chat
- Riwayat generasi tersimpan di Supabase
- Halaman Pro + paket bulanan/tahunan
- Struktur Edge Function untuk menjaga API key AI di server
- Konfigurasi EAS preview APK dan production AAB

## 1. Install
```bash
npm install
```

## 2. Supabase
Buat project Supabase, jalankan `supabase/schema.sql`, lalu salin `.env.example` menjadi `.env` dan isi:

```env
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

## 3. AI backend
Login ke Supabase CLI, lalu deploy function:

```bash
supabase functions deploy generate-ai
supabase secrets set OPENAI_API_KEY=YOUR_KEY
```

Jangan menaruh secret AI di aplikasi mobile.

## 4. Test di HP
```bash
npx expo start
```
Scan QR dari Expo Go untuk development/testing sesuai kompatibilitas perangkat.

## 5. Build Android
Untuk APK testing:
```bash
eas build --platform android --profile preview
```
Untuk Google Play:
```bash
eas build --platform android --profile production
```
Production menghasilkan AAB yang cocok untuk Google Play.

## Catatan komersial
Halaman Pro sudah disiapkan, tetapi pembayaran subscription Google Play belum diaktifkan dalam starter ini. Sebelum publikasi, hubungkan Google Play Billing atau RevenueCat, buat produk subscription di Play Console, dan implementasikan verifikasi entitlement server-side.
