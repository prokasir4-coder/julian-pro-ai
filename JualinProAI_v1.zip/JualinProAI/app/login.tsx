import { useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [signup, setSignup] = useState(false);
  const [loading, setLoading] = useState(false);

  async function submit() {
    if (!email || password.length < 6) return Alert.alert('Periksa data', 'Email dan password minimal 6 karakter.');
    setLoading(true);
    const result = signup
      ? await supabase.auth.signUp({ email: email.trim(), password })
      : await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setLoading(false);
    if (result.error) return Alert.alert('Gagal', result.error.message);
    if (signup && !result.data.session) Alert.alert('Berhasil', 'Cek email untuk verifikasi akun.');
    else router.replace('/(tabs)');
  }

  return (
    <View style={styles.root}>
      <View style={styles.logo}><Text style={styles.logoText}>JP</Text></View>
      <Text style={styles.brand}>JualinPro <Text style={styles.ai}>AI</Text></Text>
      <Text style={styles.sub}>Asisten jualan cerdas untuk UMKM Indonesia</Text>
      
      <View style={styles.card}>
        <Text style={styles.title}>{signup ? 'Buat akun' : 'Selamat datang'}</Text>
        
        <Text style={styles.label}>Email</Text>
        <TextInput value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="nama@email.com" placeholderTextColor="#94A3B8" style={styles.input}/>
        
        <Text style={styles.label}>Password</Text>
        <TextInput value={password} onChangeText={setPassword} secureTextEntry placeholder="Minimal 6 karakter" placeholderTextColor="#94A3B8" style={styles.input}/>
        
        <Pressable style={styles.button} onPress={submit} disabled={loading}>
          <Text style={styles.buttonText}>{loading ? 'Memproses...' : signup ? 'Daftar gratis' : 'Masuk'}</Text>
        </Pressable>
        
        <Pressable onPress={() => setSignup(v => !v)}>
          <Text style={styles.switch}>{signup ? 'Sudah punya akun? Masuk' : 'Belum punya akun? Daftar gratis'}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0B1220', padding: 24, justifyContent: 'center' },
  logo: { width: 64, height: 64, borderRadius: 20, backgroundColor: '#2563EB', alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  logoText: { color: '#fff', fontSize: 24, fontWeight: '900' },
  brand: { color: '#fff', fontSize: 32, fontWeight: '900' },
  ai: { color: '#60A5FA' },
  sub: { color: '#94A3B8', fontSize: 15, lineHeight: 22, marginTop: 8, marginBottom: 28 },
  card: { backgroundColor: '#fff', borderRadius: 24, padding: 22 },
  title: { fontSize: 22, fontWeight: '800', color: '#0F172A', marginBottom: 18 },
  label: { fontSize: 13, fontWeight: '700', color: '#334155', marginBottom: 7, marginTop: 8 },
  input: { borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 14, paddingHorizontal: 14, height: 50, color: '#0F172A' },
  button: { height: 52, borderRadius: 14, backgroundColor: '#2563EB', alignItems: 'center', justifyContent: 'center', marginTop: 18 },
  buttonText: { color: '#fff', fontWeight: '800', fontSize: 16 },
  switch: { textAlign: 'center', color: '#2563EB', fontWeight: '700', marginTop: 16 }
});
