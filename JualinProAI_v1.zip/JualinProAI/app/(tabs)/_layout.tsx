import { Tabs } from 'expo-router';
import { Text } from 'react-native';
export default function Layout(){return <Tabs screenOptions={{headerShown:false, tabBarActiveTintColor:'#2563EB', tabBarInactiveTintColor:'#94A3B8', tabBarStyle:{height:68,paddingBottom:10,paddingTop:8}, tabBarLabelStyle:{fontSize:11,fontWeight:'700'}}}>
<Tabs.Screen name="index" options={{title:'Beranda',tabBarIcon:()=> <Text>⌂</Text>}}/>
<Tabs.Screen name="tools" options={{title:'AI Tools',tabBarIcon:()=> <Text>✦</Text>}}/>
<Tabs.Screen name="history" options={{title:'Riwayat',tabBarIcon:()=> <Text>◷</Text>}}/>
<Tabs.Screen name="pro" options={{title:'Pro',tabBarIcon:()=> <Text>★</Text>}}/>
<Tabs.Screen name="profile" options={{title:'Profil',tabBarIcon:()=> <Text>◉</Text>}}/>
</Tabs>}
