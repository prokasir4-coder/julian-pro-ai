import { Redirect } from 'expo-router';
import { useSession } from '@/lib/session';
import { View, ActivityIndicator } from 'react-native';

export default function Index() {
  const { session, loading } = useSession();
  if (loading) return <View style={{flex:1, alignItems:'center', justifyContent:'center'}}><ActivityIndicator /></View>;
  return <Redirect href={session ? '/(tabs)' : '/login'} />;
}
