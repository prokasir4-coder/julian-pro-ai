import { Link } from 'expo-router';
import { Text, View } from 'react-native';
export default function NotFound(){return <View style={{flex:1,alignItems:'center',justifyContent:'center'}}><Text style={{fontSize:22,fontWeight:'800'}}>Halaman tidak ditemukan</Text><Link href="/" style={{marginTop:12,color:'#2563EB'}}>Kembali</Link></View>}
